<style>
	.logo {
    margin: auto;
    background: white;
    border-radius: 50% 50%;
    color: #000000b3;
    width:30px;
    height:30px;
    align-items: center;
		justify-content: center;
}
.logo>img{
		align-items: center;
		justify-content: center;
		transform: scale(2);
		object-fit: cover;
	}
  .col-md-4  {
    margin-top:7px;
  }
  .col-md-2{
    margin-top:7px;
  }
</style>

<nav class="navbar navbar-light fixed-top bg-dark" style="padding:0;">
  <div class="container-fluid mt-2 mb-2">
  	<div class="col-lg-12">
  		<div class="col-md-1 float-left" style="display: flex;">
  			<div class="logo">
  				<img src="./assets/img/soulogo.jpg" alt="">
  			</div>
  		</div>
      <div class="col-md-4 float-left text-white">
        <large><b>Placement cell Management System</b></large>
      </div>
	  	<div class="col-md-2 float-right text-white">
	  		<a href="ajax.php?action=logout" class="text-white"><?php echo $_SESSION['login_name'] ?> <i class="fa fa-power-off"></i></a>
	    </div>
    </div>
  </div>
  
</nav>